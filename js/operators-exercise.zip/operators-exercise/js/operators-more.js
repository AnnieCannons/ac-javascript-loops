// // Operators Summary: True or False Expressions

// // < Less Than
// console.log(5 < 10); // true
// console.log(10 < 5); // false

// // >= Greater Than or Equal To
// console.log(10 >= 9); // true
// console.log(9 >= 10); //

// // <= Less Than or Equal To
// console.log(9 <= 9); // true
// console.log(10 <= 9); // false

// // === Strictly Equal To
// console.log(100 === 100); // true
// console.log(100 === 101); // false

// // !== Not Strictly Equal To
// console.log(0 !== 1); // true
// console.log(0 !== 0); // false
