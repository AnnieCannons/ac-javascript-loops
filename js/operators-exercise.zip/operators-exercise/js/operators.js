// //Operator,	Meaning	and True Expressions

// //Instructions:
// //1. Highlight this whole file by pressing Command and A.
// //2. Then uncomment by pressing Command and ? key.
// //3. View the Dev Tools Console.
// //4. Refresh the page.
// //5. View the Dev Tools Console to find the line reference in your operators.js file.

// var myAge = 28;

// //Operator: ==
// //Meaning: Equality
// console.log(myAge == 28);
// console.log(myAge == "28");
// console.log(28 == "28");

// //Operator: ===
// //Meaning: Strict equality
// console.log(myAge === 28);

// //Operator: !=
// //Meaning: Inequality
// console.log(myAge != 29);

// //Operator: !==
// //Meaning: Strict inequality
// console.log(myAge != "28");
// console.log(28 != "28");

// //Operator: >
// //Meaning: Greater than
// console.log(myAge > 25);
// console.log("28" > 25);

// //Operator: >=
// //Meaning: Greater than or equal
// console.log(myAge >= 28);
// console.log("28" >= 25);

// //Operator: <
// //Meaning: Less than
// console.log(myAge < 30);
// console.log("28" < 30);

// //Operator: <=
// //Meaning: Less than or equal
// console.log(myAge <= 28);
// console.log("28" <= 28);
